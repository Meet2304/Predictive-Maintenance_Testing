import os
import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout, Masking
from tensorflow.keras.callbacks import EarlyStopping
import joblib  # for saving the scaler

# ------------------------------------------------------
# Load CMAPSS dataset
# ------------------------------------------------------

def load_data(index="FD004", features=[2, 3, 4, 7, 11, 12, 15]):
    path = os.getcwd()
    train = np.loadtxt(os.path.join(path, f"train_{index}.txt"))
    test = np.loadtxt(os.path.join(path, f"test_{index}.txt"))
    labels = np.loadtxt(os.path.join(path, f"RUL_{index}.txt"))

    col_names = ["unit_number", "time"] + \
                [f"op_setting{i}" for i in range(1, 4)] + \
                [f"sensor{i}" for i in range(1, 22)]

    train_df = pd.DataFrame(train, columns=col_names)
    test_df = pd.DataFrame(test, columns=col_names)

    selected_features = [f"sensor{i}" for i in features]
    columns = ["unit_number", "time"] + selected_features

    return train_df[columns], test_df[columns], labels

# ------------------------------------------------------
# Compute RUL for training data
# ------------------------------------------------------

def compute_rul(df):
    rul = df.groupby("unit_number")["time"].max().reset_index()
    rul.columns = ["unit_number", "max_time"]
    df = df.merge(rul, on="unit_number")
    df["RUL"] = df["max_time"] - df["time"]
    return df.drop(columns=["max_time"])

# ------------------------------------------------------
# Prepare data: scaling and sequencing
# ------------------------------------------------------

def scale_and_split(train_df, sequence_length=50):
    features = train_df.columns.difference(["unit_number", "time", "RUL"])
    scaler = MinMaxScaler()
    train_df[features] = scaler.fit_transform(train_df[features])

    sequences, labels = [], []

    for _, group in train_df.groupby("unit_number"):
        group = group.reset_index(drop=True)
        for i in range(len(group) - sequence_length):
            seq = group.iloc[i:i + sequence_length]
            sequences.append(seq[features].values)
            labels.append(seq["RUL"].values[-1])

    X = np.array(sequences)
    y = np.array(labels)
    return train_test_split(X, y, test_size=0.2, random_state=42), scaler

# ------------------------------------------------------
# Prepare test sequences
# ------------------------------------------------------

def prepare_test_data(test_df, rul_labels, scaler, sequence_length=50):
    features = test_df.columns.difference(["unit_number", "time"])
    test_df[features] = scaler.transform(test_df[features])

    sequences = []
    for _, group in test_df.groupby("unit_number"):
        group = group.reset_index(drop=True)
        if len(group) >= sequence_length:
            seq = group.iloc[-sequence_length:]
            sequences.append(seq[features].values)
        else:
            padding = np.zeros((sequence_length - len(group), len(features)))
            seq = np.vstack((padding, group[features].values))
            sequences.append(seq)

    X_test = np.array(sequences)
    y_test = rul_labels
    return X_test, y_test

# ------------------------------------------------------
# LSTM Model Definition
# ------------------------------------------------------

def build_lstm_model(input_shape):
    model = Sequential([
        Masking(mask_value=0., input_shape=input_shape),
        LSTM(64, return_sequences=False),
        Dropout(0.3),
        Dense(32, activation='relu'),
        Dense(1)
    ])
    model.compile(optimizer='adam', loss='mse', metrics=['mae'])
    return model

# ------------------------------------------------------
# Training Loop for All Datasets
# ------------------------------------------------------

def train_on_all_datasets():
    dataset_indices = ["FD001", "FD002", "FD003", "FD004"]
    sensor_features = [2, 3, 4, 7, 11, 12, 15]

    results = {}

    for index in dataset_indices:
        print(f"\n--- Training on {index} ---")
        train_df, test_df, rul_labels = load_data(index=index, features=sensor_features)
        train_df = compute_rul(train_df)

        (X_train, X_val, y_train, y_val), scaler = scale_and_split(train_df)

        model = build_lstm_model(input_shape=X_train.shape[1:])
        es = EarlyStopping(patience=10, restore_best_weights=True)

        model.fit(X_train, y_train, epochs=35, batch_size=64,
                  validation_data=(X_val, y_val), callbacks=[es], verbose=2)

        val_loss, val_mae = model.evaluate(X_val, y_val, verbose=0)
        print(f"Validation Evaluation for {index}: MSE = {val_loss:.4f}, MAE = {val_mae:.4f}")

        # Test data evaluation
        X_test, y_test = prepare_test_data(test_df, rul_labels, scaler)
        test_loss, test_mae = model.evaluate(X_test, y_test, verbose=0)
        print(f"Test Evaluation for {index}: MSE = {test_loss:.4f}, MAE = {test_mae:.4f}")

        # Save model and scaler
        model_dir = f"model_{index}"
        os.makedirs(model_dir, exist_ok=True)
        model.save(os.path.join(model_dir, "rul_lstm_model.h5"))
        joblib.dump(scaler, os.path.join(model_dir, "scaler.pkl"))

        results[index] = {
            "Val_MSE": val_loss, "Val_MAE": val_mae,
            "Test_MSE": test_loss, "Test_MAE": test_mae
        }

    print("\n--- Final Evaluation Summary ---")
    for k, v in results.items():
        print(f"{k}: Val_MSE = {v['Val_MSE']:.4f}, Val_MAE = {v['Val_MAE']:.4f}, "
              f"Test_MSE = {v['Test_MSE']:.4f}, Test_MAE = {v['Test_MAE']:.4f}")

if __name__ == "__main__":
    train_on_all_datasets()
