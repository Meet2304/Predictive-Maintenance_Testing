// ===== Main JavaScript File =====

document.addEventListener('DOMContentLoaded', function() {
    // Initialize particle background
    initParticles();
    
    // Initialize animations
    initAnimations();
    
    // Handle navbar scroll behavior
    initNavbarBehavior();
});

// ===== Particle Background =====
function initParticles() {
    const particles = document.getElementById('particles');
    
    if (!particles) return;
    
    // Create stars
    for (let i = 0; i < 100; i++) {
        createStar(particles);
    }
}

function createStar(container) {
    const star = document.createElement('div');
    star.className = 'star';
    
    // Random position
    const x = Math.random() * 100;
    const y = Math.random() * 100;
    
    // Random size
    const size = Math.random() * 3;
    
    // Random opacity
    const opacity = Math.random() * 0.7 + 0.3;
    
    // Random animation delay
    const delay = Math.random() * 5;
    
    // Set styles
    star.style.cssText = `
        position: absolute;
        top: ${y}%;
        left: ${x}%;
        width: ${size}px;
        height: ${size}px;
        background-color: rgba(255, 255, 255, ${opacity});
        border-radius: 50%;
        animation: twinkle 5s infinite ${delay}s;
    `;
    
    container.appendChild(star);
}

// ===== Global Animations =====
function initAnimations() {
    // Register GSAP scroll trigger plugin
    if (typeof ScrollTrigger !== 'undefined') {
        gsap.registerPlugin(ScrollTrigger);
    }
    
    // Animate navbar elements
    gsap.from('.navbar-brand', { 
        opacity: 0, 
        x: -20, 
        duration: 0.8, 
        ease: 'power3.out' 
    });
    
    gsap.from('.nav-item', { 
        opacity: 0, 
        y: -20, 
        stagger: 0.1, 
        duration: 0.6, 
        ease: 'power3.out',
        delay: 0.3
    });
    
    // Animate section headers when they come into view
    const headers = document.querySelectorAll('.section-header');
    
    headers.forEach(header => {
        gsap.from(header.querySelector('h1, h2'), {
            opacity: 0,
            y: 30,
            duration: 0.8,
            scrollTrigger: {
                trigger: header,
                start: 'top 80%'
            }
        });
        
        gsap.from(header.querySelector('.divider'), {
            width: 0,
            duration: 0.8,
            delay: 0.3,
            scrollTrigger: {
                trigger: header,
                start: 'top 80%'
            }
        });
        
        if (header.querySelector('.lead')) {
            gsap.from(header.querySelector('.lead'), {
                opacity: 0,
                y: 20,
                duration: 0.8,
                delay: 0.6,
                scrollTrigger: {
                    trigger: header,
                    start: 'top 80%'
                }
            });
        }
    });
    
    // Animate cards when they come into view
    const cards = document.querySelectorAll('.card');
    
    cards.forEach(card => {
        gsap.from(card, {
            opacity: 0,
            y: 50,
            duration: 0.8,
            scrollTrigger: {
                trigger: card,
                start: 'top 90%'
            }
        });
    });
}

// ===== Navbar Behavior =====
function initNavbarBehavior() {
    const navbar = document.getElementById('main-nav');
    
    if (!navbar) return;
    
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            navbar.style.padding = '0.5rem 1rem';
            navbar.style.backgroundColor = 'rgba(2, 6, 23, 0.95)';
        } else {
            navbar.style.padding = '1rem';
            navbar.style.backgroundColor = 'rgba(2, 6, 23, 0.8)';
        }
    });
}

// ===== Utility Functions =====

// Format a number with commas
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

// Format a decimal number to n decimal places
function formatDecimal(num, places = 2) {
    return Number(num).toFixed(places);
}

// Generate a random number between min and max
function randomInRange(min, max) {
    return Math.random() * (max - min) + min;
}

// Add keyframe animation dynamically
function addKeyframeAnimation(name, rules) {
    // Create a style element
    const style = document.createElement('style');
    style.type = 'text/css';
    
    // Append the keyframe rule
    const keyframeRule = `
    @keyframes ${name} {
        ${rules}
    }
    `;
    
    style.appendChild(document.createTextNode(keyframeRule));
    
    // Append to head
    document.head.appendChild(style);
}

// Add CSS animation for twinkling stars
addKeyframeAnimation('twinkle', `
    0%, 100% {
        opacity: 0.3;
        transform: scale(1);
    }
    50% {
        opacity: 1;
        transform: scale(1.2);
    }
`);
