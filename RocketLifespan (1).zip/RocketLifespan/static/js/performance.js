// ===== Performance Metrics Page Script =====

document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const datasetButtons = document.querySelectorAll('#dataset-selector button');
    const trainingHistoryChart = document.getElementById('training-history-chart');
    const rmseChart = document.getElementById('rmse-chart');
    const maeChart = document.getElementById('mae-chart');
    const metricsContainer = document.getElementById('metrics-container');
    
    // Chart instances
    let historyChartInstance = null;
    let rmseChartInstance = null;
    let maeChartInstance = null;
    
    // Current dataset
    let currentDataset = 'all';
    
    // Chart colors
    const chartColors = {
        primary: getComputedStyle(document.documentElement).getPropertyValue('--primary-color').trim(),
        secondary: getComputedStyle(document.documentElement).getPropertyValue('--secondary-color').trim(),
        accent: getComputedStyle(document.documentElement).getPropertyValue('--accent-color').trim(),
        success: getComputedStyle(document.documentElement).getPropertyValue('--success-color').trim(),
        warning: getComputedStyle(document.documentElement).getPropertyValue('--warning-color').trim(),
        danger: getComputedStyle(document.documentElement).getPropertyValue('--danger-color').trim(),
        border: getComputedStyle(document.documentElement).getPropertyValue('--border-color').trim(),
        background: getComputedStyle(document.documentElement).getPropertyValue('--card-bg').trim(),
        text: getComputedStyle(document.documentElement).getPropertyValue('--text-light').trim(),
        muted: getComputedStyle(document.documentElement).getPropertyValue('--text-muted').trim()
    };
    
    // Initialize
    init();
    
    function init() {
        // Add event listeners to dataset buttons
        datasetButtons.forEach(button => {
            button.addEventListener('click', function() {
                // Update active button
                datasetButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
                
                // Update current dataset
                currentDataset = this.dataset.dataset;
                
                // Load data
                loadPerformanceData();
            });
        });
        
        // Load initial data
        loadPerformanceData();
    }
    
    function loadPerformanceData() {
        // Show loading state
        document.getElementById('history-loader').style.display = 'block';
        document.getElementById('rmse-loader').style.display = 'block';
        document.getElementById('mae-loader').style.display = 'block';
        document.getElementById('metrics-loader').style.display = 'block';
        
        // Fetch data from API
        fetch(`/api/performance-data/?dataset=${currentDataset}`)
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    // Hide loaders
                    document.getElementById('history-loader').style.display = 'none';
                    document.getElementById('rmse-loader').style.display = 'none';
                    document.getElementById('mae-loader').style.display = 'none';
                    document.getElementById('metrics-loader').style.display = 'none';
                    
                    // Update charts and metrics
                    if (currentDataset === 'all') {
                        updateAllDatasetCharts(data.data);
                    } else {
                        updateSingleDatasetCharts(data.data);
                    }
                } else {
                    console.error('Error loading performance data:', data.message);
                }
            })
            .catch(error => {
                console.error('Error fetching performance data:', error);
            });
    }
    
    function updateSingleDatasetCharts(data) {
        // Update training history chart
        updateTrainingHistoryChart(
            data.training_history.epochs,
            data.training_history.loss,
            data.training_history.val_loss
        );
        
        // Update metrics container
        updateMetricsContainer({
            [currentDataset]: data
        });
        
        // Update comparison charts with only one dataset
        updateComparisonCharts({
            [currentDataset]: data
        });
    }
    
    function updateAllDatasetCharts(data) {
        // Get all datasets
        const datasets = Object.keys(data);
        
        // Find the dataset with the longest training history
        let longestHistory = 0;
        let longestDataset = datasets[0];
        
        datasets.forEach(dataset => {
            const length = data[dataset].training_history.epochs.length;
            if (length > longestHistory) {
                longestHistory = length;
                longestDataset = dataset;
            }
        });
        
        // Update training history chart with all datasets
        const epochs = data[longestDataset].training_history.epochs;
        const trainingData = {};
        
        datasets.forEach(dataset => {
            trainingData[dataset] = {
                loss: data[dataset].training_history.loss,
                val_loss: data[dataset].training_history.val_loss
            };
        });
        
        updateMultiDatasetTrainingChart(epochs, trainingData);
        
        // Update metrics container with all datasets
        updateMetricsContainer(data);
        
        // Update comparison charts
        updateComparisonCharts(data);
    }
    
    function updateTrainingHistoryChart(epochs, loss, val_loss) {
        // Destroy previous chart if it exists
        if (historyChartInstance) {
            historyChartInstance.destroy();
        }
        
        // Create new chart
        const ctx = trainingHistoryChart.getContext('2d');
        
        historyChartInstance = new Chart(ctx, {
            type: 'line',
            data: {
                labels: epochs,
                datasets: [
                    {
                        label: 'Training Loss',
                        data: loss,
                        borderColor: chartColors.primary,
                        backgroundColor: hexToRgba(chartColors.primary, 0.1),
                        borderWidth: 2,
                        tension: 0.3,
                        fill: true
                    },
                    {
                        label: 'Validation Loss',
                        data: val_loss,
                        borderColor: chartColors.secondary,
                        backgroundColor: hexToRgba(chartColors.secondary, 0.1),
                        borderWidth: 2,
                        tension: 0.3,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: `Training History - ${currentDataset.toUpperCase()}`,
                        color: chartColors.text,
                        font: {
                            family: 'Orbitron, sans-serif',
                            size: 16
                        }
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        backgroundColor: chartColors.background,
                        borderColor: chartColors.border,
                        borderWidth: 1,
                        titleColor: chartColors.text,
                        bodyColor: chartColors.text,
                        callbacks: {
                            title: function(tooltipItems) {
                                return `Epoch ${tooltipItems[0].label}`;
                            }
                        }
                    },
                    legend: {
                        labels: {
                            color: chartColors.text,
                            font: {
                                family: 'Rajdhani, sans-serif'
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Epoch',
                            color: chartColors.text
                        },
                        grid: {
                            color: hexToRgba(chartColors.border, 0.2)
                        },
                        ticks: {
                            color: chartColors.muted
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Loss (MSE)',
                            color: chartColors.text
                        },
                        grid: {
                            color: hexToRgba(chartColors.border, 0.2)
                        },
                        ticks: {
                            color: chartColors.muted
                        }
                    }
                },
                animation: {
                    duration: 1000,
                    easing: 'easeOutQuart'
                }
            }
        });
        
        // Animate chart appearance
        gsap.from(trainingHistoryChart, {
            opacity: 0,
            y: 20,
            duration: 0.8,
            ease: 'power3.out'
        });
    }
    
    function updateMultiDatasetTrainingChart(epochs, trainingData) {
        // Destroy previous chart if it exists
        if (historyChartInstance) {
            historyChartInstance.destroy();
        }
        
        // Color palette for datasets
        const datasetColors = [
            chartColors.primary,
            chartColors.secondary,
            chartColors.accent,
            chartColors.success
        ];
        
        // Create datasets for chart
        const chartDatasets = [];
        let colorIndex = 0;
        
        Object.keys(trainingData).forEach(dataset => {
            const color = datasetColors[colorIndex % datasetColors.length];
            colorIndex++;
            
            chartDatasets.push({
                label: `${dataset.toUpperCase()} Training`,
                data: trainingData[dataset].loss,
                borderColor: color,
                backgroundColor: 'transparent',
                borderWidth: 2,
                tension: 0.3,
                fill: false
            });
            
            chartDatasets.push({
                label: `${dataset.toUpperCase()} Validation`,
                data: trainingData[dataset].val_loss,
                borderColor: color,
                backgroundColor: 'transparent',
                borderWidth: 2,
                borderDash: [5, 5],
                tension: 0.3,
                fill: false
            });
        });
        
        // Create new chart
        const ctx = trainingHistoryChart.getContext('2d');
        
        historyChartInstance = new Chart(ctx, {
            type: 'line',
            data: {
                labels: epochs,
                datasets: chartDatasets
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Training History Comparison',
                        color: chartColors.text,
                        font: {
                            family: 'Orbitron, sans-serif',
                            size: 16
                        }
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        backgroundColor: chartColors.background,
                        borderColor: chartColors.border,
                        borderWidth: 1,
                        titleColor: chartColors.text,
                        bodyColor: chartColors.text
                    },
                    legend: {
                        labels: {
                            color: chartColors.text,
                            font: {
                                family: 'Rajdhani, sans-serif'
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Epoch',
                            color: chartColors.text
                        },
                        grid: {
                            color: hexToRgba(chartColors.border, 0.2)
                        },
                        ticks: {
                            color: chartColors.muted
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Loss (MSE)',
                            color: chartColors.text
                        },
                        grid: {
                            color: hexToRgba(chartColors.border, 0.2)
                        },
                        ticks: {
                            color: chartColors.muted
                        }
                    }
                },
                animation: {
                    duration: 1000,
                    easing: 'easeOutQuart'
                }
            }
        });
        
        // Animate chart appearance
        gsap.from(trainingHistoryChart, {
            opacity: 0,
            y: 20,
            duration: 0.8,
            ease: 'power3.out'
        });
    }
    
    function updateComparisonCharts(data) {
        updateRmseChart(data);
        updateMaeChart(data);
    }
    
    function updateRmseChart(data) {
        // Destroy previous chart if it exists
        if (rmseChartInstance) {
            rmseChartInstance.destroy();
        }
        
        // Extract data
        const datasets = Object.keys(data);
        const rmseValues = datasets.map(dataset => Math.sqrt(data[dataset].mse));
        
        // Create new chart
        const ctx = rmseChart.getContext('2d');
        
        rmseChartInstance = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: datasets.map(d => d.toUpperCase()),
                datasets: [{
                    label: 'RMSE',
                    data: rmseValues,
                    backgroundColor: datasets.map((_, i) => hexToRgba(chartColors.primary, 0.7 - i * 0.1)),
                    borderColor: chartColors.primary,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Root Mean Square Error',
                        color: chartColors.text,
                        font: {
                            family: 'Orbitron, sans-serif',
                            size: 16
                        }
                    },
                    tooltip: {
                        backgroundColor: chartColors.background,
                        borderColor: chartColors.border,
                        borderWidth: 1,
                        titleColor: chartColors.text,
                        bodyColor: chartColors.text,
                        callbacks: {
                            label: function(context) {
                                return `RMSE: ${context.raw.toFixed(2)} cycles`;
                            }
                        }
                    },
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: hexToRgba(chartColors.border, 0.2)
                        },
                        ticks: {
                            color: chartColors.muted
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Cycles',
                            color: chartColors.text
                        },
                        grid: {
                            color: hexToRgba(chartColors.border, 0.2)
                        },
                        ticks: {
                            color: chartColors.muted
                        }
                    }
                },
                animation: {
                    duration: 1000,
                    easing: 'easeOutQuart'
                }
            }
        });
        
        // Animate chart appearance
        gsap.from(rmseChart, {
            opacity: 0,
            y: 20,
            duration: 0.8,
            ease: 'power3.out',
            delay: 0.2
        });
    }
    
    function updateMaeChart(data) {
        // Destroy previous chart if it exists
        if (maeChartInstance) {
            maeChartInstance.destroy();
        }
        
        // Extract data
        const datasets = Object.keys(data);
        const maeValues = datasets.map(dataset => data[dataset].mae);
        
        // Create new chart
        const ctx = maeChart.getContext('2d');
        
        maeChartInstance = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: datasets.map(d => d.toUpperCase()),
                datasets: [{
                    label: 'MAE',
                    data: maeValues,
                    backgroundColor: datasets.map((_, i) => hexToRgba(chartColors.secondary, 0.7 - i * 0.1)),
                    borderColor: chartColors.secondary,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Mean Absolute Error',
                        color: chartColors.text,
                        font: {
                            family: 'Orbitron, sans-serif',
                            size: 16
                        }
                    },
                    tooltip: {
                        backgroundColor: chartColors.background,
                        borderColor: chartColors.border,
                        borderWidth: 1,
                        titleColor: chartColors.text,
                        bodyColor: chartColors.text,
                        callbacks: {
                            label: function(context) {
                                return `MAE: ${context.raw.toFixed(2)} cycles`;
                            }
                        }
                    },
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: hexToRgba(chartColors.border, 0.2)
                        },
                        ticks: {
                            color: chartColors.muted
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Cycles',
                            color: chartColors.text
                        },
                        grid: {
                            color: hexToRgba(chartColors.border, 0.2)
                        },
                        ticks: {
                            color: chartColors.muted
                        }
                    }
                },
                animation: {
                    duration: 1000,
                    easing: 'easeOutQuart'
                }
            }
        });
        
        // Animate chart appearance
        gsap.from(maeChart, {
            opacity: 0,
            y: 20,
            duration: 0.8,
            ease: 'power3.out',
            delay: 0.4
        });
    }
    
    function updateMetricsContainer(data) {
        let html = '';
        
        if (currentDataset === 'all') {
            // Create metrics table for all datasets
            html = `
                <table class="table table-dark table-hover">
                    <thead>
                        <tr>
                            <th>Dataset</th>
                            <th>MSE</th>
                            <th>RMSE</th>
                            <th>MAE</th>
                            <th>R²</th>
                        </tr>
                    </thead>
                    <tbody>
            `;
            
            Object.keys(data).forEach(dataset => {
                html += `
                    <tr>
                        <td>${dataset.toUpperCase()}</td>
                        <td>${data[dataset].mse.toFixed(2)}</td>
                        <td>${Math.sqrt(data[dataset].mse).toFixed(2)}</td>
                        <td>${data[dataset].mae.toFixed(2)}</td>
                        <td>${data[dataset].r2.toFixed(3)}</td>
                    </tr>
                `;
            });
            
            html += `
                    </tbody>
                </table>
            `;
        } else {
            // Create detailed metrics for a single dataset
            html = `
                <div class="metrics-details">
                    <div class="metric-item">
                        <div class="metric-title">
                            <h4>Mean Squared Error</h4>
                            <span>MSE</span>
                        </div>
                        <div class="metric-value">${data[currentDataset].mse.toFixed(2)}</div>
                        <div class="metric-description">Average squared difference between predicted and actual RUL values.</div>
                    </div>
                    
                    <div class="metric-item">
                        <div class="metric-title">
                            <h4>Root Mean Squared Error</h4>
                            <span>RMSE</span>
                        </div>
                        <div class="metric-value">${Math.sqrt(data[currentDataset].mse).toFixed(2)}</div>
                        <div class="metric-description">Square root of MSE, gives error in the same units as the target (cycles).</div>
                    </div>
                    
                    <div class="metric-item">
                        <div class="metric-title">
                            <h4>Mean Absolute Error</h4>
                            <span>MAE</span>
                        </div>
                        <div class="metric-value">${data[currentDataset].mae.toFixed(2)}</div>
                        <div class="metric-description">Average absolute difference between predicted and actual RUL values.</div>
                    </div>
                    
                    <div class="metric-item">
                        <div class="metric-title">
                            <h4>R² Score</h4>
                            <span>R²</span>
                        </div>
                        <div class="metric-value">${data[currentDataset].r2.toFixed(3)}</div>
                        <div class="metric-description">Proportion of variance explained by the model (1.0 is perfect prediction).</div>
                    </div>
                </div>
            `;
        }
        
        // Update container
        metricsContainer.innerHTML = html;
        
        // Add animation for metrics items
        gsap.from('.metric-item', {
            opacity: 0,
            y: 20,
            stagger: 0.1,
            duration: 0.8,
            ease: 'power3.out'
        });
    }
    
    // Helper function to convert hex color to rgba
    function hexToRgba(hex, alpha = 1) {
        if (!hex) return `rgba(0, 0, 0, ${alpha})`;
        
        // Remove # if present
        hex = hex.replace('#', '');
        
        // Convert to RGB
        const r = parseInt(hex.substring(0, 2), 16);
        const g = parseInt(hex.substring(2, 4), 16);
        const b = parseInt(hex.substring(4, 6), 16);
        
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }
});
