// ===== Advanced Animation Effects =====

document.addEventListener('DOMContentLoaded', function() {
    // Initialize Three.js background if available
    initThreeJsBackground();
    
    // Initialize rocket animation effects
    initRocketEffects();
    
    // Add scroll-based parallax effects
    initParallaxEffects();
    
    // Add micro-interactions
    initMicroInteractions();
});

// ===== Three.js Background Animation =====
function initThreeJsBackground() {
    // Check if Three.js is loaded
    if (typeof THREE === 'undefined') return;
    
    // Get the particles container
    const particlesElement = document.getElementById('particles');
    if (!particlesElement) return;
    
    // Clear existing children
    particlesElement.innerHTML = '';
    
    // Create scene, camera, and renderer
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    
    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x000000, 0);
    particlesElement.appendChild(renderer.domElement);
    
    // Create particle system - significantly reduced number of particles
    const particleCount = 300; // Reduced from 1500
    const particles = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);
    
    // More minimal, monochromatic color scheme
    const primaryColor = new THREE.Color(0x555555);  // Subtle gray
    const secondaryColor = new THREE.Color(0x333333);  // Darker gray
    
    // Create particles with randomized positions and colors
    for (let i = 0; i < particleCount; i++) {
        const i3 = i * 3;
        
        // Position - more spread out for minimal feel
        positions[i3] = (Math.random() - 0.5) * 120;  // x
        positions[i3 + 1] = (Math.random() - 0.5) * 120;  // y
        positions[i3 + 2] = (Math.random() - 0.5) * 120;  // z
        
        // Color - subtle monochrome variation
        const color = primaryColor.clone().lerp(secondaryColor, Math.random() * 0.5);
        colors[i3] = color.r;
        colors[i3 + 1] = color.g;
        colors[i3 + 2] = color.b;
    }
    
    particles.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particles.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    
    const particleMaterial = new THREE.PointsMaterial({
        size: 0.3, // Smaller particles
        vertexColors: true,
        transparent: true,
        opacity: 0.4, // More transparent
        sizeAttenuation: true
    });
    
    const particleSystem = new THREE.Points(particles, particleMaterial);
    scene.add(particleSystem);
    
    // Set camera position
    camera.position.z = 40; // Further away for more subtle effect
    
    // Mouse movement effect - reduced sensitivity
    let mouseX = 0;
    let mouseY = 0;
    let windowHalfX = window.innerWidth / 2;
    let windowHalfY = window.innerHeight / 2;
    
    document.addEventListener('mousemove', event => {
        mouseX = (event.clientX - windowHalfX) / 100; // Reduced sensitivity
        mouseY = (event.clientY - windowHalfY) / 100; // Reduced sensitivity
    });
    
    // Handle resize
    window.addEventListener('resize', () => {
        windowHalfX = window.innerWidth / 2;
        windowHalfY = window.innerHeight / 2;
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });
    
    // Animation loop - slower, more subtle movement
    function animate() {
        requestAnimationFrame(animate);
        
        // Rotate the particle system more slowly
        particleSystem.rotation.x += 0.0001; // Slower rotation
        particleSystem.rotation.y += 0.0002; // Slower rotation
        
        // React to mouse movement - more subtle
        camera.position.x += (mouseX - camera.position.x) * 0.02; // Reduced effect
        camera.position.y += (-mouseY - camera.position.y) * 0.02; // Reduced effect
        camera.lookAt(scene.position);
        
        renderer.render(scene, camera);
    }
    
    animate();
}

// ===== Rocket Effect Animations =====
function initRocketEffects() {
    // Animate rocket flames in the hero section
    const flames = document.querySelectorAll('.rocket-flame');
    
    flames.forEach(flame => {
        // Create flicker effect
        gsap.to(flame, {
            height: '+=10',
            opacity: 0.8,
            duration: 0.2,
            repeat: -1,
            yoyo: true,
            ease: 'power1.inOut',
            onRepeat: () => {
                // Randomize the flame width a little bit
                gsap.to(flame, {
                    width: `${Math.random() * 10 + 35}px`,
                    duration: 0.1
                });
            }
        });
    });
    
    // Add launch effect to rocket buttons
    const rocketButtons = document.querySelectorAll('.btn-primary');
    
    rocketButtons.forEach(button => {
        button.addEventListener('mouseenter', () => {
            gsap.to(button, {
                y: -3,
                boxShadow: '0 10px 20px rgba(124, 58, 237, 0.3)',
                duration: 0.3
            });
        });
        
        button.addEventListener('mouseleave', () => {
            gsap.to(button, {
                y: 0,
                boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
                duration: 0.3
            });
        });
        
        button.addEventListener('click', () => {
            // Create flame effect on click
            const flame = document.createElement('div');
            flame.className = 'btn-flame';
            flame.style.cssText = `
                position: absolute;
                bottom: -20px;
                left: 50%;
                transform: translateX(-50%);
                width: 20px;
                height: 30px;
                background: linear-gradient(#f97316, transparent);
                border-radius: 50% 50% 0 0;
                opacity: 0;
                filter: blur(3px);
            `;
            
            button.style.position = 'relative';
            button.style.overflow = 'visible';
            button.appendChild(flame);
            
            // Animate the flame
            gsap.to(flame, {
                height: 40,
                opacity: 0.8,
                duration: 0.2,
                onComplete: () => {
                    gsap.to(flame, {
                        height: 0,
                        opacity: 0,
                        duration: 0.2,
                        delay: 0.1,
                        onComplete: () => {
                            flame.remove();
                        }
                    });
                }
            });
            
            // Button press effect
            gsap.to(button, {
                y: 2,
                duration: 0.1,
                onComplete: () => {
                    gsap.to(button, {
                        y: -3,
                        duration: 0.2
                    });
                }
            });
        });
    });
}

// ===== Parallax Effects =====
function initParallaxEffects() {
    // Create parallax effect for hero section background
    const heroSection = document.querySelector('.hero-section');
    
    if (heroSection) {
        window.addEventListener('scroll', () => {
            const scrollY = window.scrollY;
            const scale = 1 + scrollY * 0.0005;
            const opacity = 1 - scrollY * 0.002;
            
            heroSection.style.backgroundSize = `${scale * 100}%`;
            heroSection.style.opacity = Math.max(0.5, opacity);
        });
    }
    
    // Parallax for cards and images
    document.addEventListener('mousemove', e => {
        const cards = document.querySelectorAll('.card');
        const mouseX = e.clientX / window.innerWidth - 0.5;
        const mouseY = e.clientY / window.innerHeight - 0.5;
        
        cards.forEach(card => {
            const rect = card.getBoundingClientRect();
            const cardCenterX = rect.left + rect.width / 2;
            const cardCenterY = rect.top + rect.height / 2;
            
            const distanceX = (e.clientX - cardCenterX) / window.innerWidth;
            const distanceY = (e.clientY - cardCenterY) / window.innerHeight;
            
            // Only apply effect if mouse is close to the card
            if (Math.abs(distanceX) < 0.3 && Math.abs(distanceY) < 0.3) {
                gsap.to(card, {
                    rotationY: distanceX * 5,
                    rotationX: -distanceY * 5,
                    duration: 0.5,
                    ease: 'power2.out'
                });
            } else {
                gsap.to(card, {
                    rotationY: 0,
                    rotationX: 0,
                    duration: 0.5,
                    ease: 'power2.out'
                });
            }
        });
    });
}

// ===== Micro-interactions =====
function initMicroInteractions() {
    // Add hover effects for navigation items
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('mouseenter', () => {
            // Create floating particles
            for (let i = 0; i < 5; i++) {
                createFloatingParticle(link);
            }
        });
    });
    
    // Add ripple effect for buttons
    const buttons = document.querySelectorAll('.btn');
    
    buttons.forEach(button => {
        button.addEventListener('click', e => {
            const rect = button.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const ripple = document.createElement('span');
            ripple.className = 'ripple-effect';
            ripple.style.left = `${x}px`;
            ripple.style.top = `${y}px`;
            
            button.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    });
    
    // Add style for ripple effect
    const style = document.createElement('style');
    style.innerHTML = `
        .ripple-effect {
            position: absolute;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            pointer-events: none;
            transform: scale(0);
            animation: ripple 0.6s linear;
            z-index: 10;
        }
        
        @keyframes ripple {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }
        
        .btn {
            position: relative;
            overflow: hidden;
        }
    `;
    
    document.head.appendChild(style);
}

function createFloatingParticle(element) {
    const particle = document.createElement('span');
    const rect = element.getBoundingClientRect();
    
    // Random position along the element
    const x = Math.random() * rect.width;
    
    particle.className = 'floating-particle';
    particle.style.cssText = `
        position: absolute;
        left: ${x}px;
        bottom: 0;
        width: 5px;
        height: 5px;
        background-color: rgba(124, 58, 237, 0.6);
        border-radius: 50%;
        pointer-events: none;
    `;
    
    element.appendChild(particle);
    
    // Animate the particle
    gsap.to(particle, {
        y: -30 - Math.random() * 20,
        x: x + (Math.random() * 20 - 10),
        opacity: 0,
        duration: 1 + Math.random(),
        onComplete: () => {
            particle.remove();
        }
    });
}
