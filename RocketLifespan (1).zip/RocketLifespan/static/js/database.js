// ===== Database Page Script =====

document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const datasetSelector = document.getElementById('dataset-selector');
    const entriesSelector = document.getElementById('entries-selector');
    const datasetDetails = document.getElementById('dataset-details');
    const tableHeader = document.getElementById('table-header');
    const tableBody = document.getElementById('table-body');
    const pagination = document.getElementById('pagination');
    const showingStart = document.getElementById('showing-start');
    const showingEnd = document.getElementById('showing-end');
    const totalEntries = document.getElementById('total-entries');
    
    // Current state
    let currentPage = 1;
    let totalPages = 1;
    let currentDataset = 'FD001';
    let entriesPerPage = 25;
    
    // Column descriptions for each sensor
    const columnDescriptions = {
        'unit_number': 'Engine unit ID',
        'time': 'Operational cycle count',
        'op_setting1': 'Altitude (ft)',
        'op_setting2': 'Mach number',
        'op_setting3': 'Throttle resolver angle (TRA)',
        'sensor1': 'Fan inlet temperature (°F)',
        'sensor2': 'LPC outlet temperature (°F)',
        'sensor3': 'HPC outlet temperature (°F)',
        'sensor4': 'LPT outlet temperature (°F)',
        'sensor5': 'Fan inlet pressure (psia)',
        'sensor6': 'Bypass-duct pressure (psia)',
        'sensor7': 'HPC outlet pressure (psia)',
        'sensor8': 'Physical fan speed (rpm)',
        'sensor9': 'Physical core speed (rpm)',
        'sensor10': 'Corrected engine pressure ratio',
        'sensor11': 'HPT coolant bleed (lbm/s)',
        'sensor12': 'LPT coolant bleed (lbm/s)',
        'sensor13': 'Fan bypass ratio',
        'sensor14': 'Burner fuel-air ratio',
        'sensor15': 'Bleed enthalpy',
        'sensor16': 'Demanded fan speed (rpm)',
        'sensor17': 'Demanded corrected fan speed (rpm)',
        'sensor18': 'HPT coolant bleed (pps)',
        'sensor19': 'LPT coolant bleed (pps)',
        'sensor20': 'Physical fan speed (%)',
        'sensor21': 'Physical core speed (%)'
    };
    
    // Dataset descriptions
    const datasetDescriptions = {
        'FD001': {
            title: 'FD001 Dataset',
            description: 'Single operating condition with a single failure mode (HPC degradation)',
            units: 100,
            operating_conditions: 1,
            failure_modes: 1,
            highlighted_sensors: [2, 3, 4, 7, 11, 12, 15]
        },
        'FD002': {
            title: 'FD002 Dataset',
            description: 'Six operating conditions with a single failure mode (HPC degradation)',
            units: 260,
            operating_conditions: 6,
            failure_modes: 1,
            highlighted_sensors: [2, 3, 4, 7, 11, 12, 15]
        },
        'FD003': {
            title: 'FD003 Dataset',
            description: 'Single operating condition with two failure modes (HPC and fan degradation)',
            units: 100,
            operating_conditions: 1,
            failure_modes: 2,
            highlighted_sensors: [2, 3, 4, 7, 11, 12, 15]
        },
        'FD004': {
            title: 'FD004 Dataset',
            description: 'Six operating conditions with two failure modes (HPC and fan degradation)',
            units: 249,
            operating_conditions: 6,
            failure_modes: 2,
            highlighted_sensors: [2, 3, 4, 7, 11, 12, 15]
        }
    };
    
    // Initialize
    init();
    
    function init() {
        // Add event listeners
        datasetSelector.addEventListener('change', function() {
            currentDataset = this.value;
            currentPage = 1;
            loadData();
        });
        
        entriesSelector.addEventListener('change', function() {
            entriesPerPage = parseInt(this.value);
            currentPage = 1;
            loadData();
        });
        
        // Load initial data
        loadData();
    }
    
    function loadData() {
        // Show loading state
        tableBody.innerHTML = `
            <tr class="skeleton-row">
                <td colspan="7"><div class="skeleton-loader"></div></td>
            </tr>
            <tr class="skeleton-row">
                <td colspan="7"><div class="skeleton-loader"></div></td>
            </tr>
            <tr class="skeleton-row">
                <td colspan="7"><div class="skeleton-loader"></div></td>
            </tr>
        `;
        
        // Update dataset details
        updateDatasetDetails();
        
        // Calculate offset
        const offset = (currentPage - 1) * entriesPerPage;
        
        // Fetch data from API
        fetch(`/api/database/?dataset=${currentDataset}&start=${offset}&length=${entriesPerPage}`)
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    // Update table
                    updateTable(data.data);
                    
                    // Update pagination
                    updatePagination(data.total);
                    
                    // Update showing info
                    updateShowingInfo(offset, data.data.length, data.total);
                } else {
                    // Show error
                    tableBody.innerHTML = `
                        <tr>
                            <td colspan="7" class="text-center text-danger">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                Error loading data: ${data.message}
                            </td>
                        </tr>
                    `;
                }
            })
            .catch(error => {
                console.error('Error fetching data:', error);
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="7" class="text-center text-danger">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            Error loading data: ${error.message}
                        </td>
                    </tr>
                `;
            });
    }
    
    function updateDatasetDetails() {
        const dataset = datasetDescriptions[currentDataset];
        
        if (!dataset) {
            datasetDetails.innerHTML = '<div class="alert alert-warning">Dataset information not available</div>';
            return;
        }
        
        // Create dataset details HTML
        datasetDetails.innerHTML = `
            <h4>${dataset.title}</h4>
            <p>${dataset.description}</p>
            <div class="dataset-stats">
                <div class="row">
                    <div class="col-md-4">
                        <div class="stat-item">
                            <div class="stat-value">${dataset.units}</div>
                            <div class="stat-label">Engine Units</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stat-item">
                            <div class="stat-value">${dataset.operating_conditions}</div>
                            <div class="stat-label">Operating Conditions</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stat-item">
                            <div class="stat-value">${dataset.failure_modes}</div>
                            <div class="stat-label">Failure Modes</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="dataset-sensors mt-3">
                <p><strong>Key Sensors:</strong> ${dataset.highlighted_sensors.map(s => `Sensor ${s}`).join(', ')}</p>
                <p class="text-muted">These sensors provide the most significant data for predicting RUL.</p>
            </div>
        `;
        
        // Add custom styles for dataset stats
        const style = document.createElement('style');
        style.textContent = `
            .dataset-stats {
                margin: 1.5rem 0;
            }
            .stat-item {
                text-align: center;
                padding: 1rem;
                background-color: rgba(15, 23, 42, 0.5);
                border-radius: 8px;
                transition: all 0.3s ease;
            }
            .stat-item:hover {
                transform: translateY(-5px);
                background-color: rgba(30, 41, 59, 0.5);
            }
            .stat-value {
                font-size: 2rem;
                font-weight: bold;
                color: var(--primary-color);
                font-family: var(--font-heading);
            }
            .stat-label {
                color: var(--text-muted);
                font-size: 0.9rem;
            }
        `;
        
        document.head.appendChild(style);
        
        // Animate stats appearance
        gsap.from('.stat-item', {
            y: 20,
            opacity: 0,
            stagger: 0.2,
            duration: 0.8,
            ease: 'power3.out'
        });
    }
    
    function updateTable(data) {
        if (!data || data.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="7" class="text-center">No data available</td>
                </tr>
            `;
            return;
        }
        
        // Get column names from the first data item
        const columns = Object.keys(data[0]);
        
        // Update table header
        tableHeader.innerHTML = '';
        columns.forEach(col => {
            const th = document.createElement('th');
            th.textContent = formatColumnName(col);
            th.title = columnDescriptions[col] || col;
            
            // Highlight important columns
            const dataset = datasetDescriptions[currentDataset];
            if (dataset && col.startsWith('sensor') && dataset.highlighted_sensors.includes(parseInt(col.replace('sensor', '')))) {
                th.className = 'bg-primary bg-opacity-25';
            }
            
            tableHeader.appendChild(th);
        });
        
        // Update table body
        tableBody.innerHTML = '';
        data.forEach(row => {
            const tr = document.createElement('tr');
            
            columns.forEach(col => {
                const td = document.createElement('td');
                td.textContent = row[col];
                
                // Highlight important columns
                const dataset = datasetDescriptions[currentDataset];
                if (dataset && col.startsWith('sensor') && dataset.highlighted_sensors.includes(parseInt(col.replace('sensor', '')))) {
                    td.className = 'bg-primary bg-opacity-10';
                }
                
                tr.appendChild(td);
            });
            
            tableBody.appendChild(tr);
        });
        
        // Add row hover animation
        const rows = tableBody.querySelectorAll('tr');
        rows.forEach(row => {
            row.addEventListener('mouseenter', () => {
                gsap.to(row, {
                    backgroundColor: 'rgba(124, 58, 237, 0.1)',
                    duration: 0.3
                });
            });
            
            row.addEventListener('mouseleave', () => {
                gsap.to(row, {
                    backgroundColor: 'transparent',
                    duration: 0.3
                });
            });
        });
    }
    
    function updatePagination(total) {
        // Calculate total pages
        totalPages = Math.ceil(total / entriesPerPage);
        
        // Generate pagination HTML
        let html = '';
        
        // Previous button
        html += `
            <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
                <a class="page-link" href="#" data-page="${currentPage - 1}">
                    <i class="fas fa-chevron-left"></i>
                </a>
            </li>
        `;
        
        // Page numbers
        const maxPages = 5;
        let startPage = Math.max(1, currentPage - Math.floor(maxPages / 2));
        let endPage = Math.min(totalPages, startPage + maxPages - 1);
        
        // Adjust if we're at the end
        if (endPage - startPage + 1 < maxPages && startPage > 1) {
            startPage = Math.max(1, endPage - maxPages + 1);
        }
        
        // First page
        if (startPage > 1) {
            html += `
                <li class="page-item">
                    <a class="page-link" href="#" data-page="1">1</a>
                </li>
            `;
            
            if (startPage > 2) {
                html += `
                    <li class="page-item disabled">
                        <span class="page-link">...</span>
                    </li>
                `;
            }
        }
        
        // Page numbers
        for (let i = startPage; i <= endPage; i++) {
            html += `
                <li class="page-item ${i === currentPage ? 'active' : ''}">
                    <a class="page-link" href="#" data-page="${i}">${i}</a>
                </li>
            `;
        }
        
        // Last page
        if (endPage < totalPages) {
            if (endPage < totalPages - 1) {
                html += `
                    <li class="page-item disabled">
                        <span class="page-link">...</span>
                    </li>
                `;
            }
            
            html += `
                <li class="page-item">
                    <a class="page-link" href="#" data-page="${totalPages}">${totalPages}</a>
                </li>
            `;
        }
        
        // Next button
        html += `
            <li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
                <a class="page-link" href="#" data-page="${currentPage + 1}">
                    <i class="fas fa-chevron-right"></i>
                </a>
            </li>
        `;
        
        // Set HTML
        pagination.innerHTML = html;
        
        // Add event listeners
        const pageLinks = pagination.querySelectorAll('.page-link');
        pageLinks.forEach(link => {
            if (link.dataset.page) {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    const page = parseInt(this.dataset.page);
                    
                    if (page !== currentPage && page >= 1 && page <= totalPages) {
                        currentPage = page;
                        loadData();
                        
                        // Scroll to top of table
                        document.querySelector('.data-table-wrapper').scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }
                });
            }
        });
    }
    
    function updateShowingInfo(start, count, total) {
        showingStart.textContent = total > 0 ? start + 1 : 0;
        showingEnd.textContent = Math.min(start + count, total);
        totalEntries.textContent = total;
    }
    
    function formatColumnName(column) {
        if (column === 'unit_number') return 'Unit';
        if (column === 'time') return 'Cycle';
        
        // Format op_settingX to Setting X
        if (column.startsWith('op_setting')) {
            const num = column.replace('op_setting', '');
            return `Setting ${num}`;
        }
        
        // Format sensorX to Sensor X
        if (column.startsWith('sensor')) {
            const num = column.replace('sensor', '');
            return `Sensor ${num}`;
        }
        
        // Default: capitalize each word
        return column
            .split('_')
            .map(word => word.charAt(0).toUpperCase() + word.slice(1))
            .join(' ');
    }
});
