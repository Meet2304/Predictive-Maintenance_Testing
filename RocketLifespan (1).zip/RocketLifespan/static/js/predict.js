// ===== Predict Page Script =====

document.addEventListener('DOMContentLoaded', function() {
    // Get DOM elements
    const sliders = document.querySelectorAll('.sensor-slider-item input');
    const randomizeBtn = document.getElementById('randomize-btn');
    const predictBtn = document.getElementById('predict-btn');
    
    const resultInitial = document.querySelector('.result-initial');
    const loadingAnimation = document.querySelector('.loading-animation');
    const resultData = document.querySelector('.result-data');
    const errorMessage = document.querySelector('.error-message');
    const errorText = document.getElementById('error-text');
    
    const resultValue = document.getElementById('result-value');
    const resultArc = document.getElementById('result-arc');
    const resultInterpretation = document.getElementById('result-interpretation');
    
    // Initialize sliders
    initSliders();
    
    // Add event listeners
    randomizeBtn.addEventListener('click', randomizeValues);
    predictBtn.addEventListener('click', predictRUL);
    
    // Initialize sliders with event listeners
    function initSliders() {
        sliders.forEach(slider => {
            const valueSpan = slider.parentElement.querySelector('.value');
            
            // Set initial value display
            valueSpan.textContent = parseFloat(slider.value).toFixed(2);
            
            // Add event listener for slider change
            slider.addEventListener('input', function() {
                valueSpan.textContent = parseFloat(this.value).toFixed(2);
            });
        });
    }
    
    // Randomize sensor values
    function randomizeValues() {
        sliders.forEach(slider => {
            const min = parseFloat(slider.min);
            const max = parseFloat(slider.max);
            const randomValue = Math.random() * (max - min) + min;
            
            // Set slider value
            slider.value = randomValue;
            
            // Update displayed value
            const valueSpan = slider.parentElement.querySelector('.value');
            valueSpan.textContent = randomValue.toFixed(2);
        });
        
        // Add rocket animation effect
        animateRocket();
    }
    
    // Predict RUL based on current slider values
    function predictRUL() {
        // Show loading animation
        resultInitial.classList.add('d-none');
        resultData.classList.add('d-none');
        errorMessage.classList.add('d-none');
        loadingAnimation.classList.remove('d-none');
        
        // Collect sensor values
        const sensorValues = {};
        sliders.forEach(slider => {
            const sensorName = slider.parentElement.dataset.sensor;
            sensorValues[sensorName] = parseFloat(slider.value);
        });
        
        // Get CSRF token
        const csrfToken = getCsrfToken();
        console.log("CSRF Token:", csrfToken ? "Found token" : "No token found");
        
        // Log the input data (for debugging)
        console.log("Sending prediction request with sensor values:", sensorValues);
        
        // Call prediction API
        fetch('/api/predict/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrfToken
            },
            body: JSON.stringify({
                sensor_values: sensorValues,
                dataset: 'FD003'  // Default dataset
            }),
            credentials: 'same-origin' // Include cookies in the request
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`Server responded with status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            // Hide loading animation
            loadingAnimation.classList.add('d-none');
            console.log("Prediction response:", data);
            
            if (data.status === 'success') {
                // Show result
                resultData.classList.remove('d-none');
                
                // Update gauge
                updateGauge(data.prediction);
                
                // Animate result appearance
                animateResult(data.prediction);
            } else {
                // Show error
                errorMessage.classList.remove('d-none');
                errorText.textContent = data.message || 'An error occurred during prediction.';
            }
        })
        .catch(error => {
            // Hide loading animation
            loadingAnimation.classList.add('d-none');
            console.error("Prediction request failed:", error);
            
            // Show error
            errorMessage.classList.remove('d-none');
            errorText.textContent = 'Network error: ' + error.message;
        });
    }
    
    // Update gauge with prediction value
    function updateGauge(prediction) {
        // Set the prediction value text
        resultValue.textContent = Math.round(prediction);
        
        // Calculate gauge arc length (0-283 corresponds to 0-100%)
        // Assuming max RUL is around 150 cycles
        const maxRUL = 150;
        const percentage = Math.min(1, prediction / maxRUL);
        const arcLength = percentage * 283;
        
        // Set the arc dash array
        resultArc.style.strokeDasharray = `${arcLength} 283`;
        
        // Set color based on prediction value
        if (prediction < 20) {
            resultArc.style.stroke = '#ef4444'; // Danger - red
            resultInterpretation.textContent = 'Critical! Maintenance required immediately. Component is nearing failure.';
        } else if (prediction < 50) {
            resultArc.style.stroke = '#f59e0b'; // Warning - amber
            resultInterpretation.textContent = 'Warning! Schedule maintenance soon. Component has moderate remaining life.';
        } else {
            resultArc.style.stroke = '#10b981'; // Success - green
            resultInterpretation.textContent = 'Good condition. Component has significant remaining useful life.';
        }
    }
    
    // Animate the result display
    function animateResult(prediction) {
        // Animate the value counting up
        const startValue = 0;
        const duration = 1500; // ms
        const startTime = performance.now();
        
        function updateCounter(currentTime) {
            const elapsedTime = currentTime - startTime;
            const progress = Math.min(elapsedTime / duration, 1);
            
            // Easing function for smooth animation
            const easedProgress = 1 - Math.pow(1 - progress, 3);
            
            const currentValue = Math.round(startValue + easedProgress * (prediction - startValue));
            resultValue.textContent = currentValue;
            
            if (progress < 1) {
                requestAnimationFrame(updateCounter);
            }
        }
        
        requestAnimationFrame(updateCounter);
    }
    
    // Rocket animation effect
    function animateRocket() {
        // Create a rocket element
        const rocket = document.createElement('div');
        rocket.className = 'randomize-rocket';
        rocket.innerHTML = `
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="30" height="30">
                <path fill="var(--primary-color)" d="M156.6 384.9L125.7 354c-8.5-8.5-11.5-20.8-7.7-32.2c3-8.9 7-20.5 11.8-33.8L24 288c-8.6 0-16.6-4.6-20.9-12.1s-4.2-16.7 .2-24.1l52.5-88.5c13-21.9 36.5-35.3 61.9-35.3l82.3 0c2.4-4 4.8-7.7 7.2-11.3C289.1-4.1 411.1-8.1 483.9 5.3c11.6 2.1 20.6 11.2 22.8 22.8c13.4 72.9 9.3 194.8-111.4 276.7c-3.5 2.4-7.3 4.8-11.3 7.2v82.3c0 25.4-13.4 49-35.3 61.9l-88.5 52.5c-7.4 4.4-16.6 4.5-24.1 .2s-12.1-12.2-12.1-20.9V288l-57.4-28.5c-13.3 4.8-24.9 8.8-33.8 11.8c-11.4 3.8-23.7 .8-32.2-7.7L125.7 234c-7.7-7.7-10.1-19.1-6.3-29.1L144.4 127c-28.7-23.7-55.3-58.8-77.3-91.4C57.7 22.9 63.9 6.2 77.7 2.5c5.2-1.4 10.8-.3 14.9 3.1l29.4 24.5c16.8 14 34.8 26.1 54 36.1V38c0-10.6 5.3-20.5 14.2-26.3c8.9-5.8 20.1-6.4 29.5-1.5L244 31.9c22.3 11.2 43.3 24.8 62.7 40.6c5.7 4.6 8.7 11.5 8.2 18.7s-4.9 13.5-11.2 17.2l-23.5 13.6c-7.5 4.3-17.3 3.7-24.2-1.6c-7.3-5.6-14.8-10.7-22.6-15.5L216 93.4V175z" />
            </svg>
            <div class="rocket-trail"></div>
        `;
        
        // Add rocket to the page
        document.body.appendChild(rocket);
        
        // Position rocket at the randomize button
        const btnRect = randomizeBtn.getBoundingClientRect();
        rocket.style.cssText = `
            position: fixed;
            top: ${btnRect.top + btnRect.height/2}px;
            left: ${btnRect.left + btnRect.width/2}px;
            transform: translate(-50%, -50%) rotate(-45deg);
            z-index: 1000;
            pointer-events: none;
        `;
        
        // Animate rocket flying around sliders
        const firstSlider = sliders[0].getBoundingClientRect();
        const lastSlider = sliders[sliders.length - 1].getBoundingClientRect();
        
        // Create timeline for complex animation
        const tl = gsap.timeline({
            onComplete: () => rocket.remove()
        });
        
        tl.to(rocket, {
            top: firstSlider.top,
            left: firstSlider.right + 50,
            duration: 0.4,
            ease: "power1.out"
        })
        .to(rocket, {
            top: lastSlider.bottom + 30,
            left: lastSlider.right + 20,
            duration: 0.8,
            ease: "none",
            rotate: "-30deg",
        })
        .to(rocket, {
            top: btnRect.bottom + 50,
            left: btnRect.left - 50,
            duration: 0.4,
            ease: "power1.in",
            rotate: "-90deg",
            opacity: 0
        });
    }
    
    // Get CSRF token from cookies or meta tag
    function getCsrfToken() {
        // First try to get from cookies
        let cookieValue = document.cookie
            .split('; ')
            .find(row => row.startsWith('csrftoken='))
            ?.split('=')[1];
            
        // If not found in cookies, try to get from meta tag
        if (!cookieValue) {
            const metaTag = document.querySelector('meta[name="csrf-token"]');
            if (metaTag) {
                cookieValue = metaTag.getAttribute('content');
            }
        }
        
        // If still not found, try to get from hidden input
        if (!cookieValue) {
            const inputTag = document.querySelector('input[name="csrfmiddlewaretoken"]');
            if (inputTag) {
                cookieValue = inputTag.value;
            }
        }
        
        return cookieValue || '';
    }
    
    // Add custom styles for rocket animation
    const style = document.createElement('style');
    style.textContent = `
        .randomize-rocket {
            position: fixed;
            z-index: 1000;
        }
        
        .rocket-trail {
            position: absolute;
            top: 70%;
            left: 50%;
            width: 10px;
            height: 30px;
            background: linear-gradient(var(--accent-color), transparent);
            border-radius: 50% 50% 0 0;
            filter: blur(3px);
            transform: translate(-50%, 0) rotate(180deg);
            opacity: 0.7;
            animation: flameFlicker 0.1s infinite alternate;
        }
        
        @keyframes flameFlicker {
            0% { height: 30px; opacity: 0.7; }
            100% { height: 25px; opacity: 0.5; }
        }
    `;
    
    document.head.appendChild(style);
});
