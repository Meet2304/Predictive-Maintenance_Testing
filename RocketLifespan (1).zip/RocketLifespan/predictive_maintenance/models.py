from django.db import models

# Models for the application
