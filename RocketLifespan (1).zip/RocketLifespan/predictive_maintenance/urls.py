from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('predict/', views.predict, name='predict'),
    path('database/', views.database, name='database'),
    path('performance/', views.performance, name='performance'),
    path('team/', views.team, name='team'),
    path('model-code/', views.model_code, name='model_code'),
    
    # API endpoints
    path('api/predict/', views.api_predict, name='api_predict'),
    path('api/database/', views.api_database, name='api_database'),
    path('api/performance-data/', views.api_performance_data, name='api_performance_data'),
]
