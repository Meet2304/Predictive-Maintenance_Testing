from django.apps import AppConfig


class PredictiveMaintenanceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'predictive_maintenance'
